# communicating-models
Towards the development of a synthetic language by AI agents.
